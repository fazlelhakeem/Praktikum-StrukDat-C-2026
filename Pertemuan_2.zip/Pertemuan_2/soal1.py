stok = [15, 50, 30, 25, 40]

#soal 1
stok.append(100)

#soal 2
stok.insert(2,75)

#soal 3
stok.sort()
stok.reverse()

#soal 4
jumlah = 0

for x in stok :
   jumlah += x

rata = jumlah / len(stok)

#soal 5
print(stok)