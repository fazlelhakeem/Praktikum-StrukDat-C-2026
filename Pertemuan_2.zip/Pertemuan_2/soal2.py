barang = ("B001", "Laptop Gaming", 15000000)

#soal 1
print(barang[2])

#soal 2
barang[2] = 14000000  #ini akan error karena tuple unchangeable 

#soal 3
(kode, nama, harga) = barang