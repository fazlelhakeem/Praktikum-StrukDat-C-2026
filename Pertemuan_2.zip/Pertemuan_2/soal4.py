nilai_siswa = {
   "S01": {"nama": "Dina", "tugas": 80, "uts": 75, "uas": 85},
   "S02": {"nama": "Abdul Harris", "tugas": 90, "uts": 88, "uas": 92},
   "S03": {"nama": "Sheila", "tugas": 70, "uts": 65, "uas": 70}
}

#soal 1
S04 = {'nama' : 'Fafa', 'tugas' : 85, 'uts' : 80, 'uas' : 90,}

nilai_siswa.update({"S04": S04})

#soal 2
nilai1 = (nilai_siswa['S01']['tugas'] *20/100) + (nilai_siswa['S01']['uts'] *30/100) + (nilai_siswa['S01']['uas'] *50/100)

nilai2 = (nilai_siswa['S02']['tugas'] *20/100) + (nilai_siswa['S02']['uts'] *30/100) + (nilai_siswa['S02']['uas'] *50/100)

nilai3 = (nilai_siswa['S03']['tugas'] *20/100) + (nilai_siswa['S03']['uts'] *30/100) + (nilai_siswa['S03']['uas'] *50/100)

nilai4 = (nilai_siswa['S04']['tugas'] *20/100) + (nilai_siswa['S04']['uts'] *30/100) + (nilai_siswa['S04']['uas'] *50/100)

banding = list(nilai1, nilai2, nilai3, nilai4)
banding.sort()

#soal 3